# game_logic.py
import random
from database import cards_by_rarity

RARITY_CHANCE = [
    ("Common", 0.55), ("Rare", 0.27), ("Epic", 0.12),
    ("Legendary", 0.05), ("Mythic", 0.01),
]


def roll_rarity(bonus=0.0):
    weights = []
    for r, c in RARITY_CHANCE:
        if r in ("Legendary", "Mythic"):
            weights.append((r, c * (1 + bonus * 5)))
        else:
            weights.append((r, c))
    total = sum(w for _, w in weights)
    x = random.random() * total
    acc = 0
    for r, w in weights:
        acc += w
        if x <= acc:
            return r
    return "Common"


def open_pack(rarity_min=None, era_boost=None):
    rarity = roll_rarity()
    if rarity_min:
        order = ["Common", "Rare", "Epic", "Legendary", "Mythic"]
        if order.index(rarity) < order.index(rarity_min):
            rarity = rarity_min
    pool = cards_by_rarity(rarity)
    if not pool:
        pool = cards_by_rarity("Common")
    if era_boost:
        boosted = [c for c in pool if c[2] == era_boost]
        if boosted and random.random() < 0.5:
            pool = boosted
    return random.choice(pool)


def simulate_battle(cards1, cards2, era_boost=None):
    def team_strength(team):
        if not team:
            return 0, 0
        sc = []
        df = []
        for c in team:
            boost = 1.1 if era_boost and c[2] == era_boost else 1.0
            sc.append(c[4] * boost)
            df.append(c[7] * boost)
        return sum(sc) / len(sc), sum(df) / len(df)

    s1, d1 = team_strength(cards1)
    s2, d2 = team_strength(cards2)

    def score(off, opp_def):
        base = 0.5 + (off - opp_def) / 200
        base = max(0.25, min(0.75, base))
        points = 0
        for _ in range(40):
            if random.random() < base:
                points += random.choice([2, 2, 2, 3])
        return points

    a = score(s1, d2)
    b = score(s2, d1)
    if a == b:
        a += random.choice([0, 2])
    return a, b


def best_five(inv):
    def eff(c):
        return c[9] + (c[-2] - 1) * 3
    return sorted(inv, key=eff, reverse=True)[:5]