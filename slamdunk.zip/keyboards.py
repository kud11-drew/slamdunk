# keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton as B


def kb(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def main_menu():
    return kb([
        [B(text="🏀 Профиль", callback_data="profile"),
         B(text="🎴 Инвентарь", callback_data="inventory")],
        [B(text="📦 Паки", callback_data="packs"),
         B(text="⚔️ PvP", callback_data="pvp")],
        [B(text="🏰 Сквад", callback_data="squad"),
         B(text="🏆 Топ", callback_data="top")],
        [B(text="🎯 Мини-игра", callback_data="mini"),
         B(text="🎁 Ежедневка", callback_data="daily")],
        [B(text="💰 Аукцион", callback_data="auction"),
         B(text="🎫 Battle Pass", callback_data="bp")],
        [B(text="🏅 Достижения", callback_data="achv"),
         B(text="📅 Сезон", callback_data="season")],
    ])


def back_menu():
    return kb([[B(text="⬅️ Назад", callback_data="menu")]])


def packs_menu():
    return kb([
        [B(text="⚡ Быстрый (4ч)", callback_data="pack:fast")],
        [B(text="🔥 Усиленный (8ч)", callback_data="pack:mid")],
        [B(text="💎 Премиум (16ч)", callback_data="pack:prem")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def pvp_menu():
    return kb([
        [B(text="⚔️ Найти бой", callback_data="pvp:fight")],
        [B(text="📜 История", callback_data="pvp:history")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def squad_menu(has_squad):
    if has_squad:
        return kb([
            [B(text="👥 Состав", callback_data="squad:members")],
            [B(text="⚔️ Война сквадов", callback_data="war")],
            [B(text="🚪 Выйти", callback_data="squad:leave")],
            [B(text="⬅️ Назад", callback_data="menu")],
        ])
    return kb([
        [B(text="➕ Создать сквад", callback_data="squad:create")],
        [B(text="🔎 Топ сквадов", callback_data="top:squads")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def mini_menu():
    return kb([
        [B(text="🎯 Точный бросок", callback_data="mini:shot")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def auction_menu():
    return kb([
        [B(text="🛒 Лоты", callback_data="auc:browse")],
        [B(text="📤 Выставить карту", callback_data="auc:list")],
        [B(text="📋 Мои лоты", callback_data="auc:mine")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def bp_menu():
    return kb([
        [B(text="🎁 Получить награды", callback_data="bp:claim")],
        [B(text="⭐ Купить Premium", callback_data="bp:buy")],
        [B(text="⬅️ Назад", callback_data="menu")],
    ])


def war_menu(has_war, is_captain):
    rows = []
    if has_war:
        rows.append([B(text="⚔️ Сразиться за сквад", callback_data="war:fight")])
        rows.append([B(text="📊 Счёт войны", callback_data="war:score")])
    else:
        if is_captain:
            rows.append([B(text="🔎 Найти противника", callback_data="war:search")])
        else:
            rows.append([B(text="⏳ Ждём капитана...", callback_data="noop")])
    rows.append([B(text="⬅️ Назад", callback_data="menu")])
    return kb(rows)


def achv_menu():
    return kb([[B(text="⬅️ Назад", callback_data="menu")]])


def admin_menu():
    return kb([
        [B(text="📊 Статистика", callback_data="adm:stats")],
        [B(text="👥 Найти юзера", callback_data="adm:find")],
        [B(text="💰 Выдать монеты", callback_data="adm:money")],
        [B(text="🎴 Выдать карту", callback_data="adm:give"),
         B(text="🗑 Забрать карту", callback_data="adm:take")],
        [B(text="📢 Рассылка", callback_data="adm:broadcast")],
        [B(text="📜 Логи", callback_data="adm:logs")],
        [B(text="🚫 Бан/Разбан", callback_data="adm:ban")],
        [B(text="📅 Новый сезон", callback_data="adm:newseason")],
        [B(text="🎴 Добавить карту", callback_data="adm:addcard")],
        [B(text="📦 Резерв БД", callback_data="adm:backup")],
    ])