# handlers_v2.py
import time
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message

import database as db
import battlepass as bp_mod
import achievements as achv
import seasons as seasons_mod
from config import (AUCTION_COMMISSION, AUCTION_MIN_PRICE, AUCTION_MAX_HOURS,
                    BP_PREMIUM_PRICE, BP_XP_PER_LEVEL, BP_MAX_LEVEL,
                    WAR_MAX_BATTLES)
from keyboards import (auction_menu, bp_menu, achv_menu, war_menu,
                       back_menu, main_menu)

router = Router()
STATE = {}


# ================= AUCTION =================
@router.callback_query(F.data == "auction")
async def cb_auction(c: CallbackQuery):
    db.clear_expired_listings()
    await c.message.edit_text(
        "💰 <b>Аукцион</b>\n"
        f"Комиссия: {int(AUCTION_COMMISSION*100)}%\n"
        f"Мин. цена: {AUCTION_MIN_PRICE} монет\n"
        f"Макс. срок: {AUCTION_MAX_HOURS} ч",
        reply_markup=auction_menu())
    await c.answer()


@router.callback_query(F.data == "auc:browse")
async def cb_auc_browse(c: CallbackQuery):
    lots = db.active_listings(20)
    if not lots:
        return await c.message.edit_text("🛒 Лотов нет.", reply_markup=auction_menu())
    lines = ["🛒 <b>Активные лоты</b>\n"]
    for l in lots:
        # l: 0 id,1 seller,2 card_id,3 price,4 created,5 expires,6 buyer,7 status,8 name,9 rarity,10 ovr,11 skin
        lines.append(f"#{l[0]} {l[11]} <b>{l[8]}</b> [{l[9]}] OVR{l[10]} — {l[3]}💰")
    lines.append("\nЧтобы купить — отправь: <code>buy ID</code>")
    await c.message.edit_text("\n".join(lines), reply_markup=auction_menu())
    await c.answer()


@router.callback_query(F.data == "auc:list")
async def cb_auc_list(c: CallbackQuery):
    STATE[c.from_user.id] = "auc_list"
    inv = db.user_inventory(c.from_user.id)
    if not inv:
        return await c.answer("Инвентарь пуст", show_alert=True)
    lines = ["📤 <b>Что выставить?</b>\n"]
    for x in inv[:25]:
        lines.append(f"ID {x[0]} — {x[10]} {x[1]} [{x[3]}] OVR {x[9]}")
    lines.append("\nОтправь: <code>sell CARD_ID PRICE</code>")
    lines.append(f"Например: <code>sell {inv[0][0]} 500</code>")
    await c.message.edit_text("\n".join(lines), reply_markup=auction_menu())
    await c.answer()


@router.callback_query(F.data == "auc:mine")
async def cb_auc_mine(c: CallbackQuery):
    lots = db.user_listings(c.from_user.id)
    if not lots:
        return await c.message.edit_text("📋 У тебя нет активных лотов.",
                                          reply_markup=auction_menu())
    lines = ["📋 <b>Твои лоты</b>\n"]
    for l in lots:
        lines.append(f"#{l[0]} {l[11]} {l[8]} — {l[3]}💰")
    lines.append("\nОтмена: <code>cancel LOT_ID</code>")
    await c.message.edit_text("\n".join(lines), reply_markup=auction_menu())
    await c.answer()


# ================= BATTLE PASS =================
@router.callback_query(F.data == "bp")
async def cb_bp(c: CallbackQuery):
    s = seasons_mod.get_or_create_active_season()
    uid = c.from_user.id
    bp = bp_mod.ensure_bp(uid, s[0])
    xp_in_level = bp[2] % BP_XP_PER_LEVEL
    text = (
        f"🎫 <b>Battle Pass — Сезон #{s[1]}</b>\n\n"
        f"Уровень: <b>{bp[3]}/{BP_MAX_LEVEL}</b>\n"
        f"XP: {bp[2]} ({xp_in_level}/{BP_XP_PER_LEVEL} до след.)\n"
        f"Премиум: {'✅' if bp[4] else '❌'}\n\n"
        f"Награды: каждые 5 ур. — Epic/Stars, каждые 10 — Legendary/Mythic\n"
        f"Премиум: {BP_PREMIUM_PRICE} ⭐"
    )
    await c.message.edit_text(text, reply_markup=bp_menu())
    await c.answer()


@router.callback_query(F.data == "bp:claim")
async def cb_bp_claim(c: CallbackQuery):
    s = seasons_mod.get_or_create_active_season()
    uid = c.from_user.id
    bp = bp_mod.ensure_bp(uid, s[0])
    claimed = bp[5].split(",") if bp[5] else []
    granted = []
    for lvl in range(1, bp[3] + 1):
        if str(lvl) in claimed:
            continue
        kind, amt, name = bp_mod.free_reward(lvl)
        bp_mod.grant_reward(uid, kind, amt)
        granted.append(f"Lv{lvl}: {name}")
        if bp[4]:
            k2, a2, n2 = bp_mod.premium_reward(lvl)
            bp_mod.grant_reward(uid, k2, a2)
            granted.append(f"  ⭐ Lv{lvl}: {n2}")
        db.claim_bp_level(uid, lvl)
    if not granted:
        return await c.answer("Нечего получать", show_alert=True)
    await c.message.edit_text("🎁 <b>Получено:</b>\n" + "\n".join(granted[:25]),
                              reply_markup=bp_menu())
    await c.answer()


@router.callback_query(F.data == "bp:buy")
async def cb_bp_buy(c: CallbackQuery):
    s = seasons_mod.get_or_create_active_season()
    uid = c.from_user.id
    bp = bp_mod.ensure_bp(uid, s[0])
    if bp[4]:
        return await c.answer("Уже куплено", show_alert=True)
    # тут должен быть Telegram Stars invoice
    # Упрощённо: списываем со счёта Stars, если бы был, но у нас их нет — заглушка.
    u = db.get_user(uid)
    if u[2] < BP_PREMIUM_PRICE * 10:
        return await c.answer(
            f"Недостаточно монет для демо-покупки (нужно {BP_PREMIUM_PRICE*10}).\n"
            f"В проде — оплата через Telegram Stars.",
            show_alert=True)
    db.add_balance(uid, -BP_PREMIUM_PRICE * 10, "bp_premium_demo")
    db.update_battlepass(uid, premium=1)
    await c.message.edit_text("⭐ Premium Battle Pass активирован!",
                              reply_markup=bp_menu())
    await c.answer()


# ================= ACHIEVEMENTS =================
@router.callback_query(F.data == "achv")
async def cb_achv(c: CallbackQuery):
    items = db.user_achievements(c.from_user.id)
    if not items:
        return await c.message.edit_text("🏅 Достижений пока нет.",
                                          reply_markup=back_menu())
    lines = ["🏅 <b>Достижения</b>\n"]
    for code, name, desc, unlocked in items:
        mark = "✅" if unlocked else "🔒"
        lines.append(f"{mark} <b>{name}</b> — {desc}")
    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer()


# ================= SQUAD WARS =================
@router.callback_query(F.data == "war")
async def cb_war(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    if not u[5]:
        return await c.answer("Ты не в скваде", show_alert=True)
    sq = db.get_squad(u[5])
    is_captain = sq[2] == c.from_user.id
    war = db.active_war_for_squad(u[5])
    if war:
        txt = (f"⚔️ <b>Война!</b>\n"
               f"Сквад1 ({war[1]}): {war[3]}\n"
               f"Сквад2 ({war[2]}): {war[4]}\n"
               f"Битв: {war[5]}/{WAR_MAX_BATTLES}")
    else:
        txt = "⚔️ Войны нет. Капитан может запустить поиск противника."
    await c.message.edit_text(txt, reply_markup=war_menu(bool(war), is_captain))
    await c.answer()


@router.callback_query(F.data == "war:search")
async def cb_war_search(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    if not u[5]:
        return await c.answer("Нет сквада", show_alert=True)
    sq = db.get_squad(u[5])
    if sq[2] != c.from_user.id:
        return await c.answer("Только капитан", show_alert=True)
    # ищем противника
    all_sq = db.all_squads()
    enemy = None
    for s in all_sq:
        if s[0] != u[5]:
            # проверяем, что у него нет активной войны
            if not db.active_war_for_squad(s[0]):
                enemy = s
                break
    if not enemy:
        return await c.answer("Нет доступных соперников", show_alert=True)
    wid = db.create_war(u[5], enemy[0])
    await c.message.edit_text(f"⚔️ Война началась против <b>{enemy[1]}</b>!",
                              reply_markup=war_menu(True, True))
    await c.answer("Начали!")


@router.callback_query(F.data == "war:fight")
async def cb_war_fight(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    war = db.active_war_for_squad(u[5])
    if not war:
        return await c.answer("Войны нет", show_alert=True)
    my_sid = u[5]
    enemy_sid = war[2] if war[1] == my_sid else war[1]
    if db.user_battles_in_war(war[0], c.from_user.id) >= 2:
        return await c.answer("Ты уже сражался 2 раза в этой войне", show_alert=True)

    my_inv = db.user_inventory(c.from_user.id)
    if len(my_inv) < 5:
        return await c.answer("Нужно 5 карт", show_alert=True)

    from game_logic import best_five, simulate_battle
    import random
    my_team = best_five(my_inv)

    enemy_members = db.squad_members(enemy_sid)
    if not enemy_members:
        return await c.answer("У противника нет игроков", show_alert=True)
    enemy_uid = random.choice(enemy_members)[0]
    enemy_inv = db.user_inventory(enemy_uid)
    if not enemy_inv:
        enemy_team = random.sample(db.all_cards(), 5)
    else:
        enemy_team = best_five(enemy_inv)

    s = seasons_mod.get_or_create_active_season()
    s1, s2 = simulate_battle(my_team, enemy_team, era_boost=seasons_mod.era_boost(s))
    won = 1 if s1 > s2 else 0
    db.add_war_battle(war[0], c.from_user.id, my_sid, won)

    reward = 200 if won else 50
    db.add_balance(c.from_user.id, reward, "war")
    db.add_squad_rating(my_sid, 5 if won else 1)

    # Проверка конца
    w = db.get_war(war[0])
    if w[5] >= WAR_MAX_BATTLES:
        winner_sid = w[1] if w[3] > w[4] else w[2]
        db.update_war(war[0], status='finished', finished_at=int(time.time()))
        db.add_squad_rating(winner_sid, 50)
        # достижение всем победителям
        for m in db.squad_members(winner_sid):
            achv.try_unlock(m[0], "war_win")
        txt = (f"🏆 Война завершена!\n"
               f"Победил сквад #{winner_sid}\n"
               f"Твой бой: {'победа' if won else 'поражение'} {s1}:{s2}")
    else:
        txt = f"⚔️ {'🏆 Победа' if won else '😤 Поражение'} в бою!\nСчёт: {s1}:{s2}\n💰 +{reward}"

    await c.message.edit_text(txt, reply_markup=war_menu(True, False))
    await c.answer()


@router.callback_query(F.data == "war:score")
async def cb_war_score(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    war = db.active_war_for_squad(u[5])
    if not war:
        return await c.answer("Войны нет", show_alert=True)
    s1 = db.get_squad(war[1])
    s2 = db.get_squad(war[2])
    txt = (f"📊 <b>Счёт войны</b>\n"
           f"{s1[1]}: {war[3]}\n"
           f"{s2[1]}: {war[4]}\n"
           f"Битв: {war[5]}/{WAR_MAX_BATTLES}")
    await c.message.edit_text(txt, reply_markup=war_menu(True, False))
    await c.answer()


# ================= УНИВЕРСАЛЬНЫЙ ВВОД =================
@router.message(F.text)
async def handle_text(m: Message):
    mode = STATE.get(m.from_user.id)
    if not mode:
        return
    parts = m.text.split()
    try:
        if mode == "auc_list" and parts[0] == "sell" and len(parts) == 3:
            card_id, price = int(parts[1]), int(parts[2])
            if price < AUCTION_MIN_PRICE:
                return await m.answer(f"Мин. цена {AUCTION_MIN_PRICE}")
            if not db.take_card(m.from_user.id, card_id, 1):
                return await m.answer("Нет такой карты")
            lid = db.create_listing(m.from_user.id, card_id, price, AUCTION_MAX_HOURS)
            db.log_admin(m.from_user.id, "auction_list", 0, f"lot={lid}")
            await m.answer(f"✅ Лот #{lid} выставлен за {price}")
        elif parts[0] == "buy" and len(parts) == 2:
            lid = int(parts[1])
            ok, msg = db.buy_listing(lid, m.from_user.id)
            if not ok:
                return await m.answer(f"❌ {msg}")
            l = db.get_listing(lid)
            price = l[3]
            commission = int(price * AUCTION_COMMISSION)
            seller_gets = price - commission
            db.add_balance(m.from_user.id, -price, "auction_buy")
            db.add_balance(l[1], seller_gets, "auction_sell")
            db.give_card(m.from_user.id, l[2], 1)
            db.mark_sold(lid, m.from_user.id)
            achv.try_unlock(l[1], "auction_first")
            await m.answer(f"✅ Куплено за {price}, продавцу {seller_gets}")
        elif parts[0] == "cancel" and len(parts) == 2:
            lid = int(parts[1])
            l = db.get_listing(lid)
            if not l or l[1] != m.from_user.id:
                return await m.answer("Не твой лот")
            if db.cancel_listing(lid, m.from_user.id):
                db.give_card(m.from_user.id, l[2], 1)
                await m.answer(f"✅ Лот #{lid} отменён, карта возвращена")
            else:
                await m.answer("Не удалось отменить")
    except Exception as e:
        await m.answer(f"❌ {e}")
    STATE.pop(m.from_user.id, None)