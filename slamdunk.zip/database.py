# database.py
import sqlite3
import time
from config import DB_PATH, START_BALANCE

conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()


def init_db():
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        balance INTEGER DEFAULT 0,
        xp INTEGER DEFAULT 0,
        level INTEGER DEFAULT 1,
        squad_id INTEGER DEFAULT 0,
        title TEXT DEFAULT 'Новичок',
        banned INTEGER DEFAULT 0,
        last_daily INTEGER DEFAULT 0,
        streak INTEGER DEFAULT 0,
        last_seen INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT 0,
        donate_total INTEGER DEFAULT 0,
        wins INTEGER DEFAULT 0,
        losses INTEGER DEFAULT 0,
        season_points INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS cards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, era TEXT, rarity TEXT,
        sc INTEGER, rb INTEGER, pl INTEGER, df INTEGER, at INTEGER,
        ovr INTEGER, skin TEXT, is_event INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS inventory (
        user_id INTEGER, card_id INTEGER,
        level INTEGER DEFAULT 1, count INTEGER DEFAULT 1,
        obtained_at INTEGER,
        PRIMARY KEY (user_id, card_id)
    );

    CREATE TABLE IF NOT EXISTS packs (
        user_id INTEGER PRIMARY KEY,
        last_fast INTEGER DEFAULT 0,
        last_mid INTEGER DEFAULT 0,
        last_prem INTEGER DEFAULT 0,
        streak INTEGER DEFAULT 0,
        streak_start INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS squads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE, emblem TEXT,
        captain_id INTEGER, balance INTEGER DEFAULT 0,
        rating INTEGER DEFAULT 0, created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS squad_members (
        squad_id INTEGER, user_id INTEGER,
        role TEXT DEFAULT 'Новичок', joined_at INTEGER,
        PRIMARY KEY (squad_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS admin_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER, action TEXT, target_id INTEGER,
        meta TEXT, created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, amount INTEGER, type TEXT,
        meta TEXT, created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS seasons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        number INTEGER, start_at INTEGER, end_at INTEGER,
        active INTEGER DEFAULT 1, meta_era TEXT
    );

    CREATE TABLE IF NOT EXISTS achievements (
        code TEXT PRIMARY KEY, name TEXT, description TEXT,
        reward_money INTEGER, reward_xp INTEGER, reward_title TEXT
    );

    CREATE TABLE IF NOT EXISTS user_achievements (
        user_id INTEGER, code TEXT, unlocked_at INTEGER,
        PRIMARY KEY (user_id, code)
    );

    CREATE TABLE IF NOT EXISTS auctions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id INTEGER, card_id INTEGER, price INTEGER,
        created_at INTEGER, expires_at INTEGER,
        buyer_id INTEGER DEFAULT 0, status TEXT DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS battlepass (
        user_id INTEGER PRIMARY KEY, season_id INTEGER,
        xp INTEGER DEFAULT 0, level INTEGER DEFAULT 0,
        premium INTEGER DEFAULT 0, claimed TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS squad_wars (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        squad1_id INTEGER, squad2_id INTEGER,
        score1 INTEGER DEFAULT 0, score2 INTEGER DEFAULT 0,
        battles_done INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active',
        created_at INTEGER, finished_at INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS squad_war_battles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        war_id INTEGER, user_id INTEGER, squad_id INTEGER,
        won INTEGER, created_at INTEGER
    );
    """)
    conn.commit()


# ---------- USERS ----------
def get_user(uid):
    cur.execute("SELECT * FROM users WHERE id=?", (uid,))
    return cur.fetchone()


def create_user(uid, username):
    if get_user(uid):
        return
    now = int(time.time())
    cur.execute("""INSERT INTO users(id,username,balance,last_seen,created_at)
                   VALUES(?,?,?,?,?)""", (uid, username or "", START_BALANCE, now, now))
    cur.execute("INSERT INTO packs(user_id) VALUES(?)", (uid,))
    conn.commit()


def update_user(uid, **kw):
    if not kw:
        return
    fields = ", ".join(f"{k}=?" for k in kw)
    cur.execute(f"UPDATE users SET {fields} WHERE id=?", (*kw.values(), uid))
    conn.commit()


def add_balance(uid, amount, reason="unknown"):
    cur.execute("UPDATE users SET balance = balance + ? WHERE id=?", (amount, uid))
    cur.execute("""INSERT INTO transactions(user_id,amount,type,created_at)
                   VALUES(?,?,?,?)""", (uid, amount, reason, int(time.time())))
    conn.commit()


def add_xp(uid, amount):
    cur.execute("UPDATE users SET xp = xp + ? WHERE id=?", (amount, uid))
    conn.commit()


def ban_user(uid, val):
    cur.execute("UPDATE users SET banned=? WHERE id=?", (val, uid))
    conn.commit()


def set_title(uid, title):
    cur.execute("UPDATE users SET title=? WHERE id=?", (title, uid))
    conn.commit()


def all_user_ids(only_active=True):
    q = "SELECT id FROM users" + (" WHERE banned=0" if only_active else "")
    cur.execute(q)
    return [r[0] for r in cur.fetchall()]


def top_users(limit=10):
    cur.execute("""SELECT id, username, level, wins, title, season_points
                   FROM users WHERE banned=0
                   ORDER BY season_points DESC, wins DESC LIMIT ?""", (limit,))
    return cur.fetchall()


def reset_season_points():
    cur.execute("UPDATE users SET season_points=0")
    cur.execute("UPDATE squads SET rating=0")
    conn.commit()


# ---------- CARDS ----------
def add_card(name, era, rarity, sc, rb, pl, df, at, skin="🏀", is_event=0):
    ovr = int(sc * 0.3 + rb * 0.2 + pl * 0.2 + df * 0.15 + at * 0.15)
    cur.execute("""INSERT INTO cards(name,era,rarity,sc,rb,pl,df,at,ovr,skin,is_event)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (name, era, rarity, sc, rb, pl, df, at, ovr, skin, is_event))
    conn.commit()
    return cur.lastrowid


def get_card(cid):
    cur.execute("SELECT * FROM cards WHERE id=?", (cid,))
    return cur.fetchone()


def all_cards():
    cur.execute("SELECT * FROM cards")
    return cur.fetchall()


def cards_by_rarity(rarity):
    cur.execute("SELECT * FROM cards WHERE rarity=?", (rarity,))
    return cur.fetchall()


def delete_card(cid):
    cur.execute("DELETE FROM cards WHERE id=?", (cid,))
    conn.commit()


def count_cards():
    cur.execute("SELECT COUNT(*) FROM cards")
    return cur.fetchone()[0]


# ---------- INVENTORY ----------
def give_card(uid, card_id, count=1):
    now = int(time.time())
    cur.execute("SELECT count FROM inventory WHERE user_id=? AND card_id=?", (uid, card_id))
    row = cur.fetchone()
    if row:
        cur.execute("UPDATE inventory SET count=count+? WHERE user_id=? AND card_id=?",
                    (count, uid, card_id))
    else:
        cur.execute("""INSERT INTO inventory(user_id,card_id,level,count,obtained_at)
                       VALUES(?,?,1,?,?)""", (uid, card_id, count, now))
    conn.commit()


def take_card(uid, card_id, count=1):
    cur.execute("SELECT count FROM inventory WHERE user_id=? AND card_id=?", (uid, card_id))
    row = cur.fetchone()
    if not row or row[0] < count:
        return False
    if row[0] == count:
        cur.execute("DELETE FROM inventory WHERE user_id=? AND card_id=?", (uid, card_id))
    else:
        cur.execute("UPDATE inventory SET count=count-? WHERE user_id=? AND card_id=?",
                    (count, uid, card_id))
    conn.commit()
    return True


def user_inventory(uid):
    cur.execute("""SELECT c.*, i.level, i.count FROM inventory i
                   JOIN cards c ON c.id = i.card_id WHERE i.user_id=?
                   ORDER BY c.ovr DESC""", (uid,))
    return cur.fetchall()


# ---------- PACKS ----------
def get_packs(uid):
    cur.execute("SELECT * FROM packs WHERE user_id=?", (uid,))
    row = cur.fetchone()
    if not row:
        cur.execute("INSERT INTO packs(user_id) VALUES(?)", (uid,))
        conn.commit()
        cur.execute("SELECT * FROM packs WHERE user_id=?", (uid,))
        row = cur.fetchone()
    return row


def update_pack(uid, **kw):
    fields = ", ".join(f"{k}=?" for k in kw)
    cur.execute(f"UPDATE packs SET {fields} WHERE user_id=?", (*kw.values(), uid))
    conn.commit()


# ---------- SQUADS ----------
def create_squad(name, emblem, captain_id):
    try:
        cur.execute("""INSERT INTO squads(name,emblem,captain_id,created_at)
                       VALUES(?,?,?,?)""", (name, emblem, captain_id, int(time.time())))
        sid = cur.lastrowid
        cur.execute("""INSERT INTO squad_members(squad_id,user_id,role,joined_at)
                       VALUES(?,?,?,?)""", (sid, captain_id, "Капитан", int(time.time())))
        cur.execute("UPDATE users SET squad_id=? WHERE id=?", (sid, captain_id))
        conn.commit()
        return sid
    except sqlite3.IntegrityError:
        return None


def get_squad(sid):
    cur.execute("SELECT * FROM squads WHERE id=?", (sid,))
    return cur.fetchone()


def get_squad_by_name(name):
    cur.execute("SELECT * FROM squads WHERE name=?", (name,))
    return cur.fetchone()


def squad_members(sid):
    cur.execute("""SELECT u.id, u.username, u.level, u.wins, sm.role
                   FROM squad_members sm JOIN users u ON u.id = sm.user_id
                   WHERE sm.squad_id=? ORDER BY u.wins DESC""", (sid,))
    return cur.fetchall()


def squad_size(sid):
    cur.execute("SELECT COUNT(*) FROM squad_members WHERE squad_id=?", (sid,))
    return cur.fetchone()[0]


def join_squad(sid, uid):
    cur.execute("SELECT squad_id FROM users WHERE id=?", (uid,))
    if cur.fetchone()[0]:
        return False
    if squad_size(sid) >= 10:
        return False
    cur.execute("""INSERT INTO squad_members(squad_id,user_id,role,joined_at)
                   VALUES(?,?,?,?)""", (sid, uid, "Новичок", int(time.time())))
    cur.execute("UPDATE users SET squad_id=? WHERE id=?", (sid, uid))
    conn.commit()
    return True


def leave_squad(uid):
    cur.execute("SELECT squad_id FROM users WHERE id=?", (uid,))
    row = cur.fetchone()
    if not row or not row[0]:
        return
    sid = row[0]
    cur.execute("DELETE FROM squad_members WHERE user_id=?", (uid,))
    cur.execute("UPDATE users SET squad_id=0 WHERE id=?", (uid,))
    sq = get_squad(sid)
    if sq and sq[2] == uid:
        cur.execute("DELETE FROM squads WHERE id=?", (sid,))
        cur.execute("UPDATE users SET squad_id=0 WHERE squad_id=?", (sid,))
        cur.execute("DELETE FROM squad_members WHERE squad_id=?", (sid,))
    conn.commit()


def add_squad_rating(sid, amount):
    cur.execute("UPDATE squads SET rating = rating + ? WHERE id=?", (amount, sid))
    conn.commit()


def add_squad_balance(sid, amount):
    cur.execute("UPDATE squads SET balance = balance + ? WHERE id=?", (amount, sid))
    conn.commit()


def top_squads(limit=10):
    cur.execute("""SELECT s.id, s.name, s.emblem, s.rating
                   FROM squads s ORDER BY s.rating DESC LIMIT ?""", (limit,))
    return cur.fetchall()


def all_squads():
    cur.execute("SELECT id, name, emblem, rating FROM squads ORDER BY rating DESC")
    return cur.fetchall()


# ---------- SEASONS ----------
def get_active_season():
    cur.execute("SELECT * FROM seasons WHERE active=1 ORDER BY id DESC LIMIT 1")
    return cur.fetchone()


def create_season(number, start_at, end_at, meta_era):
    cur.execute("""INSERT INTO seasons(number,start_at,end_at,active,meta_era)
                   VALUES(?,?,?,1,?)""", (number, start_at, end_at, meta_era))
    conn.commit()
    return cur.lastrowid


def finish_season(sid):
    cur.execute("UPDATE seasons SET active=0 WHERE id=?", (sid,))
    conn.commit()


def all_seasons():
    cur.execute("SELECT * FROM seasons ORDER BY id DESC")
    return cur.fetchall()


# ---------- ACHIEVEMENTS ----------
def add_achievement(code, name, desc, rm, rx, rt):
    cur.execute("""INSERT OR IGNORE INTO achievements(code,name,description,reward_money,reward_xp,reward_title)
                   VALUES(?,?,?,?,?,?)""", (code, name, desc, rm, rx, rt))
    conn.commit()


def has_achievement(uid, code):
    cur.execute("SELECT 1 FROM user_achievements WHERE user_id=? AND code=?", (uid, code))
    return cur.fetchone() is not None


def unlock_achievement(uid, code):
    cur.execute("""INSERT OR IGNORE INTO user_achievements(user_id,code,unlocked_at)
                   VALUES(?,?,?)""", (uid, code, int(time.time())))
    conn.commit()


def user_achievements(uid):
    cur.execute("""SELECT a.code, a.name, a.description, ua.unlocked_at
                   FROM achievements a LEFT JOIN user_achievements ua
                   ON ua.code = a.code AND ua.user_id=?
                   ORDER BY a.code""", (uid,))
    return cur.fetchall()


def all_achievements():
    cur.execute("SELECT * FROM achievements")
    return cur.fetchall()


# ---------- AUCTION ----------
def create_listing(seller_id, card_id, price, hours):
    now = int(time.time())
    cur.execute("""INSERT INTO auctions(seller_id,card_id,price,created_at,expires_at)
                   VALUES(?,?,?,?,?)""", (seller_id, card_id, price, now, now + hours * 3600))
    conn.commit()
    return cur.lastrowid


def get_listing(lid):
    cur.execute("SELECT * FROM auctions WHERE id=?", (lid,))
    return cur.fetchone()


def active_listings(limit=20):
    now = int(time.time())
    cur.execute("""SELECT a.*, c.name, c.rarity, c.ovr, c.skin
                   FROM auctions a JOIN cards c ON c.id = a.card_id
                   WHERE a.status='active' AND a.expires_at > ?
                   ORDER BY a.id DESC LIMIT ?""", (now, limit))
    return cur.fetchall()


def user_listings(uid):
    now = int(time.time())
    cur.execute("""SELECT a.*, c.name, c.rarity, c.ovr, c.skin
                   FROM auctions a JOIN cards c ON c.id = a.card_id
                   WHERE a.seller_id=? AND a.status='active' AND a.expires_at > ?
                   ORDER BY a.id DESC""", (uid, now))
    return cur.fetchall()


def buy_listing(lid, buyer_id):
    l = get_listing(lid)
    if not l or l[8] != 'active':
        return False, "Лот недоступен"
    if l[1] == buyer_id:
        return False, "Нельзя купить свой лот"
    if l[4] < int(time.time()):
        cur.execute("UPDATE auctions SET status='expired' WHERE id=?", (lid,))
        conn.commit()
        return False, "Лот истёк"
    buyer = get_user(buyer_id)
    if buyer[2] < l[3]:
        return False, "Недостаточно монет"
    return True, "ok"


def mark_sold(lid, buyer_id):
    cur.execute("UPDATE auctions SET status='sold', buyer_id=? WHERE id=?", (buyer_id, lid))
    conn.commit()


def cancel_listing(lid, uid):
    l = get_listing(lid)
    if not l or l[1] != uid or l[8] != 'active':
        return False
    cur.execute("UPDATE auctions SET status='expired' WHERE id=?", (lid,))
    conn.commit()
    return True


def clear_expired_listings():
    now = int(time.time())
    cur.execute("""SELECT id FROM auctions WHERE status='active' AND expires_at <= ?""", (now,))
    expired = cur.fetchall()
    cur.execute("UPDATE auctions SET status='expired' WHERE status='active' AND expires_at <= ?", (now,))
    conn.commit()
    return [r[0] for r in expired]


# ---------- BATTLE PASS ----------
def get_battlepass(uid):
    cur.execute("SELECT * FROM battlepass WHERE user_id=?", (uid,))
    return cur.fetchone()


def create_battlepass(uid, season_id):
    cur.execute("""INSERT OR IGNORE INTO battlepass(user_id,season_id,xp,level,premium,claimed)
                   VALUES(?,?,0,0,0,'')""", (uid, season_id))
    conn.commit()


def update_battlepass(uid, **kw):
    fields = ", ".join(f"{k}=?" for k in kw)
    cur.execute(f"UPDATE battlepass SET {fields} WHERE user_id=?", (*kw.values(), uid))
    conn.commit()


def claim_bp_level(uid, level):
    bp = get_battlepass(uid)
    if not bp:
        return False
    claimed = bp[5].split(",") if bp[5] else []
    key = str(level)
    if key in claimed:
        return False
    claimed.append(key)
    cur.execute("UPDATE battlepass SET claimed=? WHERE user_id=?", (",".join(claimed), uid))
    conn.commit()
    return True


def reset_battlepass_for_season(season_id):
    cur.execute("UPDATE battlepass SET season_id=?, xp=0, level=0, claimed=''", (season_id,))
    conn.commit()


# ---------- SQUAD WARS ----------
def create_war(s1, s2):
    now = int(time.time())
    cur.execute("""INSERT INTO squad_wars(squad1_id,squad2_id,created_at)
                   VALUES(?,?,?)""", (s1, s2, now))
    conn.commit()
    return cur.lastrowid


def get_war(wid):
    cur.execute("SELECT * FROM squad_wars WHERE id=?", (wid,))
    return cur.fetchone()


def active_war_for_squad(sid):
    cur.execute("""SELECT * FROM squad_wars
                   WHERE (squad1_id=? OR squad2_id=?) AND status='active'
                   LIMIT 1""", (sid, sid))
    return cur.fetchone()


def update_war(wid, **kw):
    fields = ", ".join(f"{k}=?" for k in kw)
    cur.execute(f"UPDATE squad_wars SET {fields} WHERE id=?", (*kw.values(), wid))
    conn.commit()


def add_war_battle(wid, uid, sid, won):
    cur.execute("""INSERT INTO squad_war_battles(war_id,user_id,squad_id,won,created_at)
                   VALUES(?,?,?,?,?)""", (wid, uid, sid, won, int(time.time())))
    cur.execute("UPDATE squad_wars SET battles_done = battles_done + 1 WHERE id=?", (wid,))
    if sid == get_war(wid)[1]:
        cur.execute("UPDATE squad_wars SET score1 = score1 + ? WHERE id=?", (1 if won else 0, wid))
    else:
        cur.execute("UPDATE squad_wars SET score2 = score2 + ? WHERE id=?", (1 if won else 0, wid))
    conn.commit()


def user_battles_in_war(wid, uid):
    cur.execute("SELECT COUNT(*) FROM squad_war_battles WHERE war_id=? AND user_id=?", (wid, uid))
    return cur.fetchone()[0]


# ---------- LOGS / STATS ----------
def log_admin(admin_id, action, target_id=0, meta=""):
    cur.execute("""INSERT INTO admin_logs(admin_id,action,target_id,meta,created_at)
                   VALUES(?,?,?,?,?)""", (admin_id, action, target_id, meta, int(time.time())))
    conn.commit()


def recent_logs(limit=20):
    cur.execute("SELECT * FROM admin_logs ORDER BY id DESC LIMIT ?", (limit,))
    return cur.fetchall()


def stats():
    cur.execute("SELECT COUNT(*) FROM users"); users = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users WHERE banned=0"); active = cur.fetchone()[0]
    cur.execute("SELECT SUM(balance) FROM users"); money = cur.fetchone()[0] or 0
    cur.execute("SELECT COUNT(*) FROM squads"); squads = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM cards"); cards = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM auctions WHERE status='active'"); auctions = cur.fetchone()[0]
    return {"users": users, "active": active, "money": money,
            "squads": squads, "cards": cards, "auctions": auctions}