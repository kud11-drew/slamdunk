# main.py
import asyncio
import logging
import sys
from flask import Flask, request

from aiogram import Bot, Dispatcher
from aiogram.types import Update
from aiogram.client.default import DefaultBotProperties

from config import BOT_TOKEN, WEBHOOK_PATH, WEBHOOK_URL
import database as db
from cards_data import seed_cards
from achievements import seed_achievements
import seasons as seasons_mod
from handlers_user import router as user_router
from handlers_v2 import router as v2_router
from handlers_admin import router as admin_router

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(message)s")

# --- init ---
db.init_db()
seed_cards()
seed_achievements()
seasons_mod.get_or_create_active_season()  # создаст первый сезон, если нет

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
dp.include_router(admin_router)
dp.include_router(v2_router)
dp.include_router(user_router)

app = Flask(__name__)
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)


@app.route("/", methods=["GET"])
def index():
    return "🏀 SLAM DUNK Bot is running"


@app.route(WEBHOOK_PATH, methods=["POST"])
def webhook():
    data = request.get_json(force=True)
    update = Update.model_validate(data, context={"bot": bot})
    loop.run_until_complete(dp.feed_update(bot, update))
    return "ok"


def set_webhook():
    asyncio.set_event_loop(loop)
    loop.run_until_complete(bot.set_webhook(WEBHOOK_URL, drop_pending_updates=True))
    print(f"✅ Webhook set: {WEBHOOK_URL}")


async def run_polling():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

import os

# Автоустановка вебхука при деплое на Render
if os.environ.get("SET_WEBHOOK") == "1":
    try:
        set_webhook()
    except Exception as e:
        print(f"Webhook setup error: {e}")

# Локальный запуск (не используется на Render)
# if __name__ == "__main__":
#     if "--polling" in sys.argv:
#         asyncio.run(run_polling())
#     else:
#         set_webhook()
#         app.run(host="0.0.0.0", port=8080)