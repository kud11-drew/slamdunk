# cards_data.py
STARTER_CARDS = [
    ("M. Johnson", "80s", "Common", 62, 55, 60, 58, 65, "🏀"),
    ("L. Bird", "80s", "Rare", 78, 65, 60, 62, 60, "☘️"),
    ("K. Abdul", "80s", "Rare", 70, 72, 55, 65, 68, "🌟"),
    ("I. Thomas", "80s", "Rare", 72, 50, 78, 60, 62, "🔥"),
    ("M. Malone", "80s", "Epic", 84, 80, 55, 68, 72, "💪"),
    ("Magic J.", "80s", "Legendary", 88, 68, 96, 70, 78, "✨"),
    ("S. Pippen", "90s", "Rare", 70, 68, 72, 80, 78, "🛡️"),
    ("P. Ewing", "90s", "Epic", 80, 78, 55, 82, 74, "🗽"),
    ("H. Olajuwon", "90s", "Epic", 82, 82, 62, 85, 78, "🌌"),
    ("C. Barkley", "90s", "Epic", 84, 82, 65, 68, 76, "🐷"),
    ("K. Malone", "90s", "Epic", 85, 78, 62, 72, 74, "📮"),
    ("D. Robinson", "90s", "Epic", 82, 80, 60, 84, 78, "🎖️"),
    ("Michael J.", "90s", "Mythic", 99, 78, 82, 88, 94, "🐐"),
    ("S. O'Neal", "90s", "Legendary", 90, 92, 55, 80, 82, "🦈"),
    ("A. Iverson", "00s", "Epic", 88, 55, 78, 65, 84, "⛓️"),
    ("T. Duncan", "00s", "Legendary", 84, 86, 65, 90, 74, "🧱"),
    ("K. Garnett", "00s", "Legendary", 82, 86, 68, 88, 80, "🐺"),
    ("D. Nowitzki", "00s", "Legendary", 88, 72, 60, 68, 72, "🇩🇪"),
    ("S. Nash", "00s", "Epic", 76, 50, 92, 58, 68, "🎯"),
    ("K. Bryant", "00s", "Mythic", 98, 70, 78, 84, 90, "🐍"),
    ("T. McGrady", "00s", "Legendary", 90, 68, 72, 70, 84, "🚀"),
    ("S. Curry", "Modern", "Mythic", 99, 55, 84, 70, 78, "🎯"),
    ("L. James", "Modern", "Mythic", 94, 82, 90, 82, 92, "👑"),
    ("K. Durant", "Modern", "Legendary", 94, 72, 72, 74, 80, "🗡️"),
    ("G. Antetokounmpo", "Modern", "Legendary", 90, 86, 72, 84, 92, "🦌"),
    ("N. Jokic", "Modern", "Legendary", 88, 82, 88, 68, 62, "🐴"),
    ("L. Doncic", "Modern", "Legendary", 92, 74, 84, 62, 72, "🧙"),
    ("J. Embiid", "Modern", "Epic", 88, 82, 62, 80, 76, "🦁"),
    ("D. Lillard", "Modern", "Epic", 86, 55, 78, 62, 72, "⌚"),
    ("J. Tatum", "Modern", "Epic", 84, 72, 68, 74, 78, "🍀"),
    ("D. Booker", "Modern", "Rare", 78, 60, 70, 62, 70, "☀️"),
    ("A. Edwards", "Modern", "Rare", 76, 65, 65, 68, 82, "🐜"),
    ("V. Wembanyama", "Modern", "Epic", 78, 82, 68, 88, 82, "🛸"),
]


def seed_cards():
    from database import all_cards, add_card
    if all_cards():
        return
    for c in STARTER_CARDS:
        add_card(*c)