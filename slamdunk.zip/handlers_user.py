# handlers_user.py
import time
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command

import database as db
import achievements as achv
import battlepass as bp
import seasons as seasons_mod
from config import PACK_CD, DAILY_BONUS, SQUAD_CREATE_COST, SQUAD_MAX, BP_XP_PER_LEVEL
from keyboards import (main_menu, back_menu, packs_menu, pvp_menu,
                       squad_menu, mini_menu)
from game_logic import open_pack, simulate_battle, best_five

router = Router()

TITLES = [(0, "Новичок"), (10, "Снайпер"), (30, "Защитник года"),
          (100, "MVP сезона"), (300, "GOAT")]


def title_by_wins(w):
    t = "Новичок"
    for need, name in TITLES:
        if w >= need:
            t = name
    return t


def user_card_line(c):
    return f"{c[10]} <b>{c[1]}</b> [{c[3]}] OVR {c[9]} Lv{c[-2]} ×{c[-1]}"


@router.message(Command("start"))
async def cmd_start(m: Message):
    uid = m.from_user.id
    db.create_user(uid, m.from_user.username or m.from_user.first_name)
    u = db.get_user(uid)
    if u[7]:
        return await m.answer("🚫 Ты забанен.")
    s = seasons_mod.get_or_create_active_season()
    bp.ensure_bp(uid, s[0])
    text = (
        "🏀 <b>SLAM DUNK</b>\n"
        "<i>Собери легенду. Выиграй сезон. Стань GOAT.</i>\n\n"
        "Открывай паки, собирай карты, играй PvP,\n"
        "вступай в сквады, торгуй на аукционе, качай Battle Pass.\n\n"
        f"💰 Баланс: <b>{u[2]}</b>\n"
        f"🏅 Уровень: <b>{u[4]}</b> | Побед: <b>{u[13]}</b>\n"
        f"📅 Сезон #{s[1]} · активная эпоха: <b>{s[5]}</b>\n"
        f"⏳ До конца: {seasons_mod.fmt_left(s)}\n\n"
        "Погнали 🔥"
    )
    await m.answer(text, reply_markup=main_menu())


@router.callback_query(F.data == "menu")
async def cb_menu(c: CallbackQuery):
    await c.message.edit_text("🏀 <b>SLAM DUNK — главное меню</b>\nВыбирай:",
                              reply_markup=main_menu())
    await c.answer()


@router.callback_query(F.data == "noop")
async def cb_noop(c: CallbackQuery):
    await c.answer()


# ---------- PROFILE ----------
@router.callback_query(F.data == "profile")
async def cb_profile(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    if not u:
        return await c.answer("Сначала /start", show_alert=True)
    sq = db.get_squad(u[5]) if u[5] else None
    inv = db.user_inventory(c.from_user.id)
    text = (
        f"🏀 <b>Профиль</b>\n"
        f"👤 {c.from_user.first_name}\n"
        f"💰 {u[2]} монет\n"
        f"⭐ Уровень {u[4]} | XP {u[3]}\n"
        f"🏅 Титул: <b>{u[6]}</b>\n"
        f"📊 Победы: {u[13]} | Поражения: {u[14]}\n"
        f"🎴 Карт: {len(inv)}\n"
        f"🏰 Сквад: {sq[1] if sq else '—'}\n"
        f"🔥 Стрик входов: {u[11]} дн.\n"
        f"🏆 Очков сезона: {u[15]}"
    )
    await c.message.edit_text(text, reply_markup=back_menu())
    await c.answer()


# ---------- INVENTORY ----------
@router.callback_query(F.data == "inventory")
async def cb_inv(c: CallbackQuery):
    inv = db.user_inventory(c.from_user.id)
    if not inv:
        return await c.message.edit_text("🎴 Инвентарь пуст. Открой пак!", reply_markup=back_menu())
    lines = ["🎴 <b>Инвентарь</b>\n"]
    for card in inv[:30]:
        lines.append(user_card_line(card))
    if len(inv) > 30:
        lines.append(f"\n...и ещё {len(inv) - 30}")
    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer()


# ---------- PACKS ----------
@router.callback_query(F.data == "packs")
async def cb_packs(c: CallbackQuery):
    p = db.get_packs(c.from_user.id)
    now = int(time.time())

    def fmt(ts, cd):
        left = ts + cd - now
        if left <= 0:
            return "✅ готов"
        return f"⏳ {left//3600}ч {(left%3600)//60}м"

    text = (
        "📦 <b>Паки</b>\n\n"
        f"⚡ Быстрый (4ч): {fmt(p[1], PACK_CD['fast'])}\n"
        f"🔥 Усиленный (8ч): {fmt(p[2], PACK_CD['mid'])}\n"
        f"💎 Премиум (16ч): {fmt(p[3], PACK_CD['prem'])}\n"
    )
    await c.message.edit_text(text, reply_markup=packs_menu())
    await c.answer()


@router.callback_query(F.data.startswith("pack:"))
async def cb_pack_open(c: CallbackQuery):
    kind = c.data.split(":")[1]
    uid = c.from_user.id
    p = db.get_packs(uid)
    now = int(time.time())
    idx = {"fast": 1, "mid": 2, "prem": 3}[kind]
    cd = PACK_CD[kind]
    if p[idx] + cd > now:
        left = p[idx] + cd - now
        return await c.answer(f"Рано! Осталось {left//3600}ч {(left%3600)//60}м", show_alert=True)

    if kind == "fast":
        rarity_min, count = None, 1
    elif kind == "mid":
        rarity_min, count = "Rare", 2
    else:
        rarity_min, count = "Epic", 3

    s = seasons_mod.get_or_create_active_season()
    era = seasons_mod.era_boost(s)

    got = [open_pack(rarity_min, era_boost=era) for _ in range(count)]
    for card in got:
        db.give_card(uid, card[0], 1)

    db.update_pack(uid, **{["", "last_fast", "last_mid", "last_prem"][idx]: now})
    if p[4] == 0 or now - p[4] > 86400 * 2:
        db.update_pack(uid, streak=1, streak_start=now)
    else:
        db.update_pack(uid, streak=p[4] + 1)

    bp.add_bp_xp(uid, s[0], 50 * count)

    unlocked = achv.check_all(uid)

    lines = [f"🎉 <b>Открыт пак ({kind})</b>\n"]
    for card in got:
        lines.append(f"{card[10]} <b>{card[1]}</b> [{card[3]}] OVR {card[9]}")
    if unlocked:
        lines.append("\n🏅 Новые достижения: " + ", ".join(unlocked))

    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer("Карты в инвентаре!")


# ---------- PVP ----------
@router.callback_query(F.data == "pvp")
async def cb_pvp(c: CallbackQuery):
    await c.message.edit_text("⚔️ <b>PvP арена</b>", reply_markup=pvp_menu())
    await c.answer()


@router.callback_query(F.data == "pvp:fight")
async def cb_pvp_fight(c: CallbackQuery):
    uid = c.from_user.id
    inv = db.user_inventory(uid)
    if len(inv) < 5:
        return await c.answer("Нужно минимум 5 карт", show_alert=True)

    my_team = best_five(inv)
    all_c = db.all_cards()
    import random
    bot_team = random.sample(all_c, min(5, len(all_c)))

    s = seasons_mod.get_or_create_active_season()
    era = seasons_mod.era_boost(s)
    s1, s2 = simulate_battle(my_team, bot_team, era_boost=era)
    win = s1 > s2

    u = db.get_user(uid)
    reward = 100 + u[4] * 5 if win else 20
    xp_gain = 15 if win else 5
    db.add_balance(uid, reward, "pvp_reward")
    db.add_xp(uid, xp_gain)
    new_wins = u[13] + (1 if win else 0)
    new_losses = u[14] + (0 if win else 1)
    db.update_user(uid, wins=new_wins, losses=new_losses,
                   level=1 + new_wins // 10,
                   title=title_by_wins(new_wins),
                   season_points=u[15] + (10 if win else 0))

    # Сквад-рейтинг
    if u[5]:
        db.add_squad_rating(u[5], 2 if win else -1)

    bp.add_bp_xp(uid, s[0], 100 if win else 30)

    # война сквадов
    if u[5]:
        war = db.active_war_for_squad(u[5])
        if war:
            db.add_war_battle(war[0], uid, u[5], 1 if win else 0)

    unlocked = achv.check_all(uid)

    my_lines = "\n".join(f"  {x[10]} {x[1]} ({x[9]})" for x in my_team)
    bot_lines = "\n".join(f"  {x[10]} {x[1]} ({x[9]})" for x in bot_team)
    text = (
        f"{'🏆 ПОБЕДА!' if win else '😤 Поражение'}\n\n"
        f"🔥 <b>Твой состав:</b>\n{my_lines}\n\n"
        f"🤖 <b>Соперник:</b>\n{bot_lines}\n\n"
        f"Счёт: <b>{s1} : {s2}</b>\n"
        f"💰 +{reward} | ⭐ +{xp_gain} XP"
    )
    if unlocked:
        text += "\n\n🏅 " + ", ".join(unlocked)
    await c.message.edit_text(text, reply_markup=pvp_menu())
    await c.answer()


@router.callback_query(F.data == "pvp:history")
async def cb_pvp_history(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    await c.message.edit_text(
        f"📜 Побед: <b>{u[13]}</b>\nПоражений: <b>{u[14]}</b>\n"
        f"Winrate: <b>{round(u[13]/max(1,u[13]+u[14])*100)}%</b>",
        reply_markup=pvp_menu())
    await c.answer()


# ---------- SQUAD ----------
@router.callback_query(F.data == "squad")
async def cb_squad(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    has = bool(u[5])
    if has:
        sq = db.get_squad(u[5])
        text = (f"🏰 <b>Сквад {sq[1]}</b> {sq[2]}\n"
                f"💰 Банк: {sq[3]}\n⚡ Рейтинг: {sq[4]}\n"
                f"👥 Состав: {db.squad_size(sq[0])}/{SQUAD_MAX}")
    else:
        text = "🏰 У тебя нет сквада. Создай свой (до 10 человек)."
    await c.message.edit_text(text, reply_markup=squad_menu(has))
    await c.answer()


@router.callback_query(F.data == "squad:create")
async def cb_squad_create(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    if u[2] < SQUAD_CREATE_COST:
        return await c.answer(f"Нужно {SQUAD_CREATE_COST} монет", show_alert=True)
    name = f"Squad_{c.from_user.id % 10000}"
    sid = db.create_squad(name, "🔥", c.from_user.id)
    if not sid:
        return await c.answer("Ошибка, попробуй позже", show_alert=True)
    db.add_balance(c.from_user.id, -SQUAD_CREATE_COST, "squad_create")
    achv.check_all(c.from_user.id)
    await c.message.edit_text(f"✅ Сквад создан! Название: <b>{name}</b>",
                              reply_markup=squad_menu(True))
    await c.answer()


@router.callback_query(F.data == "squad:members")
async def cb_squad_members(c: CallbackQuery):
    u = db.get_user(c.from_user.id)
    if not u[5]:
        return await c.answer("У тебя нет сквада", show_alert=True)
    members = db.squad_members(u[5])
    lines = [f"👥 <b>Состав ({len(members)}/{SQUAD_MAX})</b>\n"]
    for m in members:
        lines.append(f"  {m[4]} — {m[1] or m[0]} (Lv{m[2]}, {m[3]}W)")
    await c.message.edit_text("\n".join(lines), reply_markup=squad_menu(True))
    await c.answer()


@router.callback_query(F.data == "squad:leave")
async def cb_squad_leave(c: CallbackQuery):
    db.leave_squad(c.from_user.id)
    await c.message.edit_text("🚪 Ты вышел из сквада.", reply_markup=squad_menu(False))
    await c.answer()


# ---------- TOP ----------
@router.callback_query(F.data == "top")
async def cb_top(c: CallbackQuery):
    top = db.top_users(10)
    lines = ["🏆 <b>Топ-10 игроков сезона</b>\n"]
    for i, t in enumerate(top, 1):
        medal = ["🥇", "🥈", "🥉"][i - 1] if i <= 3 else f"{i}."
        lines.append(f"{medal} {t[1] or t[0]} — {t[2]}Lv, {t[3]}W, {t[5]} SP [{t[4]}]")
    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer()


@router.callback_query(F.data == "top:squads")
async def cb_top_squads(c: CallbackQuery):
    tops = db.top_squads(10)
    lines = ["🏆 <b>Топ сквадов</b>\n"]
    for i, s in enumerate(tops, 1):
        lines.append(f"{i}. {s[2]} <b>{s[1]}</b> — рейтинг {s[3]}")
    if not tops:
        lines.append("Пока никого.")
    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer()


# ---------- DAILY ----------
@router.callback_query(F.data == "daily")
async def cb_daily(c: CallbackQuery):
    uid = c.from_user.id
    u = db.get_user(uid)
    now = int(time.time())
    if now - u[9] < 86400:
        left = 86400 - (now - u[9])
        return await c.answer(f"Уже получено. Через {left//3600}ч {(left%3600)//60}м.", show_alert=True)

    new_streak = u[10] + 1 if now - u[9] < 86400 * 2 else 1
    bonus = DAILY_BONUS + new_streak * 30
    db.add_balance(uid, bonus, "daily")
    db.update_user(uid, last_daily=now, streak=new_streak)

    s = seasons_mod.get_or_create_active_season()
    bp.add_bp_xp(uid, s[0], 200)

    await c.message.edit_text(
        f"🎁 Ежедневный бонус!\n💰 +{bonus} монет\n🔥 Стрик: {new_streak} дн.",
        reply_markup=back_menu())
    await c.answer("Получено!")


# ---------- MINI-GAME ----------
@router.callback_query(F.data == "mini")
async def cb_mini(c: CallbackQuery):
    await c.message.edit_text("🎯 <b>Точный бросок</b>\nБросай!",
                              reply_markup=mini_menu())
    await c.answer()


@router.callback_query(F.data == "mini:shot")
async def cb_mini_shot(c: CallbackQuery):
    import random
    inv = db.user_inventory(c.from_user.id)
    best_sc = max((x[4] for x in inv), default=60)
    chance = min(0.85, 0.4 + best_sc / 200)

    if random.random() < chance:
        reward = random.randint(50, 200)
        db.add_balance(c.from_user.id, reward, "mini_shot")
        s = seasons_mod.get_or_create_active_season()
        bp.add_bp_xp(c.from_user.id, s[0], 50)
        txt = f"🎯 Попадание!\n💰 +{reward} монет"
    else:
        txt = "😢 Промах! Попробуй ещё."
    await c.message.edit_text(txt, reply_markup=mini_menu())
    await c.answer()


# ---------- SEASON ----------
@router.callback_query(F.data == "season")
async def cb_season(c: CallbackQuery):
    s = seasons_mod.get_or_create_active_season()
    u = db.get_user(c.from_user.id)
    top = db.top_users(3)
    lines = [
        f"📅 <b>Сезон #{s[1]}</b>",
        f"🎯 Активная эпоха: <b>{s[5]}</b> (+10% к статам)",
        f"⏳ Осталось: {seasons_mod.fmt_left(s)}",
        f"🏆 Твои очки: {u[15]}",
        "",
        "<b>Топ-3 сезона:</b>",
    ]
    for i, t in enumerate(top, 1):
        lines.append(f"{i}. {t[1] or t[0]} — {t[5]} SP")
    await c.message.edit_text("\n".join(lines), reply_markup=back_menu())
    await c.answer()