# battlepass.py
import database as db
from config import BP_MAX_LEVEL, BP_XP_PER_LEVEL


def ensure_bp(uid, season_id):
    bp = db.get_battlepass(uid)
    if not bp or bp[1] != season_id:
        db.create_battlepass(uid, season_id)
        bp = db.get_battlepass(uid)
    return bp


def add_bp_xp(uid, season_id, amount):
    bp = ensure_bp(uid, season_id)
    new_xp = bp[2] + amount
    new_level = min(BP_MAX_LEVEL, new_xp // BP_XP_PER_LEVEL)
    db.update_battlepass(uid, xp=new_xp, level=new_level)
    return new_level


def free_reward(level):
    if level % 10 == 0:
        return ("card_legendary", 1, "Legendary-карта")
    if level % 5 == 0:
        return ("card_epic", 1, "Epic-карта")
    return ("money", 100 + level * 20, f"{100 + level * 20} монет")


def premium_reward(level):
    if level % 10 == 0:
        return ("card_mythic", 1, "Mythic-карта")
    if level % 5 == 0:
        return ("stars", 50, "50 Stars")
    return ("money", 200 + level * 40, f"{200 + level * 40} монет")


def grant_reward(uid, kind, amount):
    if kind == "money":
        db.add_balance(uid, amount, "battlepass")
    elif kind == "stars":
        db.update_user(uid, donate_total=db.get_user(uid)[12] + amount)
        db.add_balance(uid, amount * 10, "bp_stars_bonus")
    elif kind.startswith("card_"):
        from game_logic import open_pack
        rarity = kind.split("_")[1].capitalize()
        card = open_pack(rarity_min=rarity)
        db.give_card(uid, card[0], 1)