# seasons.py
import time
import random
import database as db
from config import SEASON_DURATION, BP_XP_PER_LEVEL

ERAS = ["80s", "90s", "00s", "Modern"]


def get_or_create_active_season():
    s = db.get_active_season()
    now = int(time.time())
    if s and s[3] > now:
        return s
    if s and s[3] <= now:
        # завершаем старый, начинаем новый
        db.finish_season(s[0])
        _finalize_season(s)
        new_sid = db.create_season(s[1] + 1, now, now + SEASON_DURATION,
                                   random.choice(ERAS))
        db.reset_battlepass_for_season(new_sid)
        db.reset_season_points()
        return db.get_active_season()
    # первый запуск
    sid = db.create_season(1, now, now + SEASON_DURATION, random.choice(ERAS))
    db.reset_battlepass_for_season(sid)
    return db.get_active_season()


def _finalize_season(old_season):
    """Начислить награды топ-3 по итогам сезона."""
    from database import cur, conn, add_balance
    cur.execute("""SELECT id, username, season_points FROM users
                   WHERE banned=0 ORDER BY season_points DESC LIMIT 3""")
    winners = cur.fetchall()
    prizes = [5000, 2500, 1000]
    for i, w in enumerate(winners):
        if w[2] > 0:
            add_balance(w[0], prizes[i], f"season_reward:{old_season[1]}")


def time_left(season):
    return max(0, season[3] - int(time.time()))


def fmt_left(season):
    sec = time_left(season)
    d = sec // 86400
    h = (sec % 86400) // 3600
    return f"{d}д {h}ч"


def era_boost(season):
    return season[5] if season else None