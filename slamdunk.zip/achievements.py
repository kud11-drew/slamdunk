# achievements.py
import database as db

ACHIEVEMENTS = [
    ("first_pack",    "Первый пак",       "Открой первый пак",           100,  20,  ""),
    ("ten_wins",      "10 побед",         "10 побед в PvP",              500,  100, "Снайпер"),
    ("fifty_wins",    "50 побед",         "50 побед в PvP",              2000, 300, "Защитник года"),
    ("collector",     "Коллекционер",     "30 уникальных карт",          1000, 150, ""),
    ("legend_hunt",   "Охотник на легенд","Получить Legendary",          1500, 200, ""),
    ("mythic",        "Мифический",       "Получить Mythic",             5000, 500, "Легенда"),
    ("squad_member",  "В команде",        "Вступить в сквад",            200,  30,  ""),
    ("auction_first", "Торговец",         "Продать карту на аукционе",   300,  50,  ""),
    ("war_win",       "Победитель войны", "Выиграть сквад-войну",        800,  150, ""),
    ("bp_10",         "Прокачка",         "10 уровень BP",               1000, 100, ""),
    ("season_top10",  "Топ-10 сезона",    "Войти в топ-10 сезона",       3000, 300, "Элита"),
]


def seed_achievements():
    for a in ACHIEVEMENTS:
        db.add_achievement(*a)


def try_unlock(uid, code):
    if db.has_achievement(uid, code):
        return None
    a = next((x for x in ACHIEVEMENTS if x[0] == code), None)
    if not a:
        return None
    db.unlock_achievement(uid, code)
    db.add_balance(uid, a[3], f"achv:{code}")
    db.add_xp(uid, a[4])
    if a[5]:
        db.set_title(uid, a[5])
    return a[1]


def check_all(uid):
    u = db.get_user(uid)
    if not u:
        return []
    unlocked = []
    inv = db.user_inventory(uid)
    have_mythic = any(c[3] == "Mythic" for c in inv)
    have_legend = any(c[3] in ("Legendary", "Mythic") for c in inv)

    checks = [
        (bool(inv), "first_pack"),
        (u[13] >= 10, "ten_wins"),
        (u[13] >= 50, "fifty_wins"),
        (len(inv) >= 30, "collector"),
        (have_legend, "legend_hunt"),
        (have_mythic, "mythic"),
        (bool(u[5]), "squad_member"),
    ]
    for cond, code in checks:
        if cond:
            r = try_unlock(uid, code)
            if r:
                unlocked.append(r)

    bp = db.get_battlepass(uid)
    if bp and bp[3] >= 10:
        r = try_unlock(uid, "bp_10")
        if r:
            unlocked.append(r)

    tops = db.top_users(10)
    if any(t[0] == uid for t in tops):
        r = try_unlock(uid, "season_top10")
        if r:
            unlocked.append(r)

    return unlocked