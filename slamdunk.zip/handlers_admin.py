# handlers_admin.py
import time
import os
from functools import wraps
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.filters import Command

import database as db
import seasons as seasons_mod
from config import ADMIN_IDS, DB_PATH, SEASON_DURATION
from keyboards import admin_menu
from cards_data import STARTER_CARDS

router = Router()
STATE = {}


def admin_only(func):
    @wraps(func)
    async def wrapper(event, *args, **kwargs):
        uid = event.from_user.id if hasattr(event, "from_user") else 0
        if uid not in ADMIN_IDS:
            if isinstance(event, CallbackQuery):
                return await event.answer("Нет доступа", show_alert=True)
            return
        return await func(event, *args, **kwargs)
    return wrapper


@router.message(Command("admin"))
@admin_only
async def cmd_admin(m: Message):
    await m.answer("🛠 <b>Админ-панель SLAM DUNK</b>", reply_markup=admin_menu())


@router.callback_query(F.data == "adm:stats")
@admin_only
async def cb_stats(c: CallbackQuery):
    s = db.stats()
    season = seasons_mod.get_or_create_active_season()
    text = (
        "📊 <b>Статистика</b>\n\n"
        f"👥 Игроков: {s['users']}\n"
        f"✅ Активных: {s['active']}\n"
        f"💰 Монет в обороте: {s['money']}\n"
        f"🏰 Сквадов: {s['squads']}\n"
        f"🎴 Карт в пуле: {s['cards']}\n"
        f"🛒 Лотов: {s['auctions']}\n\n"
        f"📅 Сезон #{season[1]} ({season[5]}), до конца: {seasons_mod.fmt_left(season)}"
    )
    await c.message.edit_text(text, reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:find")
@admin_only
async def cb_find(c: CallbackQuery):
    STATE[c.from_user.id] = "find"
    await c.message.edit_text("🔎 Отправь user_id:", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:money")
@admin_only
async def cb_money(c: CallbackQuery):
    STATE[c.from_user.id] = "money"
    await c.message.edit_text("💰 Формат: <code>user_id amount</code>", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:give")
@admin_only
async def cb_give(c: CallbackQuery):
    STATE[c.from_user.id] = "give"
    await c.message.edit_text("🎴 Формат: <code>user_id card_id</code>", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:take")
@admin_only
async def cb_take(c: CallbackQuery):
    STATE[c.from_user.id] = "take"
    await c.message.edit_text("🗑 Формат: <code>user_id card_id</code>", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:ban")
@admin_only
async def cb_ban(c: CallbackQuery):
    STATE[c.from_user.id] = "ban"
    await c.message.edit_text("🚫 Формат: <code>user_id 1/0</code>", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:broadcast")
@admin_only
async def cb_broadcast(c: CallbackQuery):
    STATE[c.from_user.id] = "broadcast"
    await c.message.edit_text("📢 Отправь текст рассылки:", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:logs")
@admin_only
async def cb_logs(c: CallbackQuery):
    logs = db.recent_logs(15)
    lines = ["📜 <b>Последние действия</b>\n"]
    for l in logs:
        t = time.strftime("%d.%m %H:%M", time.localtime(l[5]))
        lines.append(f"[{t}] adm {l[1]} → {l[2]} | {l[3]} {l[4]}")
    if not logs:
        lines.append("Пусто.")
    await c.message.edit_text("\n".join(lines), reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:newseason")
@admin_only
async def cb_newseason(c: CallbackQuery):
    old = db.get_active_season()
    if old:
        db.finish_season(old[0])
    now = int(time.time())
    import random
    era = random.choice(["80s", "90s", "00s", "Modern"])
    sid = db.create_season((old[1] + 1) if old else 1, now, now + SEASON_DURATION, era)
    db.reset_battlepass_for_season(sid)
    db.reset_season_points()
    db.log_admin(c.from_user.id, "new_season", 0, f"sid={sid} era={era}")
    await c.message.edit_text(f"✅ Новый сезон #{sid} ({era}) запущен.",
                              reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:addcard")
@admin_only
async def cb_addcard(c: CallbackQuery):
    STATE[c.from_user.id] = "addcard"
    await c.message.edit_text(
        "🎴 Формат: <code>name | era | rarity | sc rb pl df at | skin</code>\n"
        "Пример: <code>Test | 90s | Epic | 80 80 70 75 78 | 🔥</code>",
        reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "adm:backup")
@admin_only
async def cb_backup(c: CallbackQuery):
    if os.path.exists(DB_PATH):
        await c.message.answer_document(FSInputFile(DB_PATH), caption="📦 Бэкап БД")
    await c.answer("Готово")

def _admin_in_state(m: Message) -> bool:
    return m.from_user.id in ADMIN_IDS and m.from_user.id in STATE

@router.message(F.text, _admin_in_state)
async def admin_input(m: Message):
    mode = STATE.get(m.from_user.id)
    if not mode:
        return
    parts = m.text.split()

    try:
        if mode == "find":
            uid = int(parts[0])
            u = db.get_user(uid)
            if not u:
                await m.answer("Не найден.")
            else:
                inv = db.user_inventory(uid)
                await m.answer(
                    f"👤 {u[1]} (ID {uid})\n💰 {u[2]}\n⭐ Lv{u[4]} XP{u[3]}\n"
                    f"🏅 {u[6]}\n🏰 squad {u[5]}\n🚫 ban={u[7]}\n"
                    f"📊 {u[13]}W/{u[14]}L\n🎴 {len(inv)} карт\n"
                    f"🏆 SP: {u[15]}"
                )
        elif mode == "money":
            uid, amt = int(parts[0]), int(parts[1])
            db.add_balance(uid, amt, f"admin:{m.from_user.id}")
            db.log_admin(m.from_user.id, "money", uid, str(amt))
            await m.answer(f"✅ {uid}: {amt:+}")
        elif mode == "give":
            uid, cid = int(parts[0]), int(parts[1])
            db.give_card(uid, cid, 1)
            db.log_admin(m.from_user.id, "give_card", uid, f"card={cid}")
            await m.answer("✅ Выдано")
        elif mode == "take":
            uid, cid = int(parts[0]), int(parts[1])
            ok = db.take_card(uid, cid, 1)
            db.log_admin(m.from_user.id, "take_card", uid, f"card={cid} ok={ok}")
            await m.answer(f"✅ {'Забрано' if ok else 'Не найдено'}")
        elif mode == "ban":
            uid, val = int(parts[0]), int(parts[1])
            db.ban_user(uid, val)
            db.log_admin(m.from_user.id, "ban", uid, str(val))
            await m.answer(f"✅ {uid} ban={val}")
        elif mode == "broadcast":
            text = m.text
            all_uids = db.all_user_ids()
            sent = 0
            for uid in all_uids:
                try:
                    await m.bot.send_message(uid, text)
                    sent += 1
                except Exception:
                    pass
            db.log_admin(m.from_user.id, "broadcast", 0, f"sent={sent}")
            await m.answer(f"📢 Отправлено: {sent}/{len(all_uids)}")
        elif mode == "addcard":
            raw = m.text.split("|")
            name = raw[0].strip()
            era = raw[1].strip()
            rarity = raw[2].strip()
            stats = list(map(int, raw[3].split()))
            skin = raw[4].strip() if len(raw) > 4 else "🏀"
            cid = db.add_card(name, era, rarity, *stats, skin=skin)
            db.log_admin(m.from_user.id, "add_card", 0, f"cid={cid}")
            await m.answer(f"✅ Карта #{cid} добавлена")
    except Exception as e:
        await m.answer(f"❌ Ошибка: {e}")

    STATE.pop(m.from_user.id, None)